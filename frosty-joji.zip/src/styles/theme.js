export const theme = {
  colors: {
    primary: "#1E1E60",
    secondary: "#4C6EF5",
    accent: "#FFC700",
  },
};
